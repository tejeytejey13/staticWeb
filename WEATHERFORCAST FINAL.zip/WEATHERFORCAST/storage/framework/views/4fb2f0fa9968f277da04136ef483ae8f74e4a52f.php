<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <title>Document</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="stylesheet" href="PIKACHUSTYLE.css">
    <link rel="stylesheet" href="css\app.css">
    <link href="https://fonts.googleapis.com/css2?family=Hubballi&family=Montserrat:wght@500&family=Oswald:wght@500&display=swap" rel="stylesheet">
</head>
<body>
    <div class="Base">
        <img class="logo" src="">
        <form method="POST" action=<?php echo e(route('city')); ?>>
            <br><br><input class= "search" type="text" placeholder="Search City" name="city">
            <input type="submit" name="submit" value="Search">
        </form>
        <?php if(isset()): ?>
        <div class="output">
            <h3>City: <?php echo e($data['getCurrentCity']); ?></h3>
            <h3>Temperature: <?php echo e($data['getCurrentTemp'] -272.15); ?>°C</h3>
            <h3>Feels Like: <?php echo e($data['getCurrentFeel'] - 272.15); ?>°C</h3>
            <h3>Humidity: <?php echo e($data['getCurrentHumidity']); ?>%</h3>
            <h3>Weather: <?php echo e($data['getCurrentWeather']); ?></h3><h3><?php echo e($getCurrent_Icon); ?></h3>
            <h3>Description: <?php echo e($data['getCurrentDescription']); ?></h3>
        </div>
        <?php endif; ?>
        <div class="single forecast-block bordered">
           <p>7 Days Forcast<?php echo e($data['getCurrentCity']); ?></p>
           <?php
           for($num = 1; $num <=7; $num++){
           ?>
           <h3><?php $day_time  = $data->daily[$num]->dt; echo date('l',$day_time)?></h3>
           <h3><?php $weather_days = $data->daily[$num]->weather[0]->main; echo $weather_days?></h3>
           <h3><?php $tem_day  = $data->daily[$num]->feels_like->day; echo $tem_day-272.15?>°C</h3>
           <h3><?php $tem_night  = $data->daily[$num]->feels_like->night; echo $tem_night-272.15?>°C</h3>
           <?php 
           }
           ?>
        </div>
    </div>
</body>
</html>
<?php /**PATH C:\Users\user\Desktop\UM_LARAVEL\WEATHERFORCAST\resources\views\forecast.blade.php ENDPATH**/ ?>