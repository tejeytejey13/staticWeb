<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <title>Document</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="stylesheet" href="PIKACHUSTYLE.css">
    <link rel="stylesheet" href="css\app.css">
    <link href="https://fonts.googleapis.com/css2?family=Hubballi&family=Montserrat:wght@500&family=Oswald:wght@500&display=swap" rel="stylesheet">
</head>
<body>
    <ul>
        <h3>WEATHERFORCAST</h3>
        <li><a href={{ route('aboutPage') }}>About</a></li>
        <li><a href={{ route('homePage') }}>Home</a></li>
    </ul>
    <div class="Base">
        <div class="search">
            <img class="logo" src="">
            <form method="POST" action={{ route('city') }}>
                @csrf
                <br><br><input class= "search" type="text" placeholder="Search City" name="city">
                <input type="submit" name="submit" value="Search">
            </form>
        </div>
        @isset($currentData)
            <div class="output">
                <h3>City: {{ $currentData['city'] }}</h3>
                <h3>Temperature: {{ $currentData['temp'] -272.15 }}°C</h3>
                <h3>Feels Like: {{ $currentData['feel'] - 272.15 }}°C</h3>
                <h3>Humidity: {{ $currentData['humidity']}}%</h3>
                <h3>Weather: {{ $currentData['weather'] }}
                <h3>Description: {{ $currentData['description'] }}</h3>
            </div><br><br>
        @endisset
        @isset($currentData)
        <p class="forcast">7 Days Forcast {{ $currentData['city'] }}</p>
        @for($num = 1; $num <=7; $num++)
        <div class="single forecast-block bordered">
            <h3>{{ date('l',$currentData['data']->daily[$num]->dt) }}</h3>
            <h3>Weather: {{ $currentData['data']->daily[$num]->weather[0]->main}}</h3>
            <h3>Day: {{ $currentData['data']->daily[$num]->feels_like->day-272.15 }}°C</h3>
            <h3>Night: {{ $tem_night  = $currentData['data']->daily[$num]->feels_like->night-272.15 }}°C</h3>
        </div>
        @endfor
        @endisset
    </div>
</body>
</html>
