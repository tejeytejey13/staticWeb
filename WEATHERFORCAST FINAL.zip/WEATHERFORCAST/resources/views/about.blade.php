<!DOCTYPE html>
<html>

<head>
    <title>About</title>
    <link rel="stylesheet" href="css\aboutstyle.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Hubballi&family=Montserrat:wght@500&display=swap" rel="stylesheet"> 
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="stylesheet" href="PIKACHUSTYLE.css">
    <link rel="stylesheet" href="css\app.css">
    <link href="https://fonts.googleapis.com/css2?family=Hubballi&family=Montserrat:wght@500&family=Oswald:wght@500&display=swap" rel="stylesheet">   
   
</head>

<body>
    <ul>
        <h3>WEATHERFORCAST</h3>
        <li><a href={{ route('aboutPage') }}>About</a></li>
        <li><a href={{ route('homePage') }}>Home</a></li>
    </ul>
        <div class="head">
            <div class="paragraph">
                <h1>ABOUT</h1>
                <h2 style="text-align:center; margin:1cm 1cm 1cm 1cm">Weather forecasting is the science of predicting what the atmosphere will be like at a 
                certain location utilizing technology and scientific understanding. In other words, it's a method of anticipating events such as Temperature, 
                feels like, pressure, humidity, dew point, clouds, visibility, wind speed, and weather.
                </h2>
                <h1>OUR TEAM</h1>
                <div class="team">
                    <div class="picture1">
                        <img class="profile"
                            src="https://scontent.fmnl25-3.fna.fbcdn.net/v/t39.30808-1/271733625_625144515473118_3770614205827092786_n.jpg?stp=dst-jpg_s200x200&amp;_nc_cat=107&amp;ccb=1-6&amp;_nc_sid=7206a8&amp;_nc_eui2=AeEczu-RYIACKF9VsOw5v8qphsibwaMB4uOGyJvBowHi41U-IfLBt2_hWxLlQVjEI59fx4LgA14HlLw5eZcT5s1J&amp;_nc_ohc=EJNcv7zL6vQAX-0WChq&amp;_nc_oc=AQkzd0aByFMGEl43RaKl8igvFDANS_mGJINq7vQZW3dl8C-lXRxqx2nJswsmDurEzZo&amp;_nc_ht=scontent.fmnl25-3.fna&amp;oh=00_AT8vQ7Bmv3VcUzl4pSyhd5D-W89hZGGxd5d9_RjVAmhnRw&amp;oe=6288EF32"><br>
                        <strong>Christian Jay D. Salonoy</strong><br>
                        <p>IT STUDENT</p>
                    </div>
                    <div class="picture2">
                        <img class="profile"
                        src="https://scontent-xsp1-3.xx.fbcdn.net/v/t39.30808-6/255046580_1574124606269131_72183692435221075_n.jpg?_nc_cat=111&amp;ccb=1-6&amp;_nc_sid=09cbfe&amp;_nc_eui2=AeE8uJZ2AGBVseZzXD-p7S2V6k6tGRyRKKPqTq0ZHJEooxCuy3HYlSyh-J8og_8QvOdAVA4myCQ5h5SjaXx8ly-C&amp;_nc_ohc=bglHIRoLsBsAX9EyZ98&amp;_nc_ht=scontent-xsp1-3.xx&amp;oh=00_AT9Re0zDFnmXbsMO2A0JMN1at_kAqHPY7vMV7XkRDiuhHA&amp;oe=628952F4">
                        <br><strong>Thomas Jon A. Barrientos</strong>
                        <p>IT STUDENT</p>
                    </div>
                </div>
                <div class="picture3">
                    <img class="profile"
                        src="https://scontent-xsp1-1.xx.fbcdn.net/v/t1.6435-1/102941068_2684533068535625_5400633615126771206_n.jpg?stp=dst-jpg_p200x200&amp;_nc_cat=105&amp;ccb=1-6&amp;_nc_sid=7206a8&amp;_nc_eui2=AeFLLBrLWLZbl_xJQfmNmaZWBUuDbpEw1rMFS4NukTDWs5u3HMLxrr8JG6IY6te57PPbFGsVwpvPIw2qXxwYrtX2&amp;_nc_ohc=OcilpIfWO_8AX_uYIZZ&amp;tn=X_EevpJb88xjU7zA&amp;_nc_ht=scontent-xsp1-1.xx&amp;oh=00_AT-R-88pnQC9ntNLCHk2XYYC81pDR5rW6EzsEQBzYp8eXw&amp;oe=62AA00FD">
                    <br><strong>Abdul Salapuddin Abdila</strong>
                    <p>IT STUDENT</p>
                </div>
                <div class="picture4">
                    <img class="profile" style="width: 203px;"
                        src="https://scontent.fdvo2-1.fna.fbcdn.net/v/t1.6435-1/37930260_1055061471320067_5907988022594371584_n.jpg?stp=dst-jpg_p200x200&amp;_nc_cat=100&amp;ccb=1-6&amp;_nc_sid=7206a8&amp;_nc_eui2=AeEuFYTyVouOTGSxnH1dwpmGSkm-7z0quJJKSb7vPSq4ktnGDB1toHuyffIDnXH80FlLyLbn702F7oCrxy_8DNJo&amp;_nc_ohc=OE7yHYeHOY4AX-uhxgH&amp;_nc_ht=scontent.fdvo2-1.fna&amp;oh=00_AT-bmzXtInCQrYa6QS_ZqV2BKZIluTCI8q4DC4E1GJ3Y8w&amp;oe=62A98685">
                    <br><strong>Christian Jake Bueza</strong>
                    <p>IT STUDENT</p>
                </div>
                <div class="picture5">
                    <img class="profile"
                        src="https://scontent-xsp1-1.xx.fbcdn.net/v/t39.30808-1/278977167_5206087449451004_9043408064337960403_n.jpg?stp=dst-jpg_s200x200&amp;_nc_cat=105&amp;ccb=1-6&amp;_nc_sid=7206a8&amp;_nc_eui2=AeE0Kce5ahXC_HkYmx08W2hEXsVJk9ailmJexUmT1qKWYow5DzRvsASwIsw85vkEB2QQP_PSogL-HDkOuRq6N-cI&amp;_nc_ohc=f9vCbvIsXQEAX99BzfB&amp;_nc_ht=scontent-xsp1-1.xx&amp;oh=00_AT-eoTsuh2kS5oDPd8ZxX-z3Au4ablPjhY70nanF4X2qaA&amp;oe=62895E0D">
                    <br><strong>Keanu Brua</strong>
                    <p>IT STUDENT</p>
                </div>
            </div>
        </div>
    </div>
    </div>
</body>

</html>
