<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Geolocation extends Controller
{   
    public function getLocation(Request $request){
        if ($request->filled('city')) 
        {
            $city = str_replace(' ', '%',  $request->city);
            $currentData = $this->getApiData($city);
        } else {
            $currentData = $this->getApiData('manila');
        }
        return view('forecast', compact('currentData'));
    }
    
    private function getApiData(String $city) {
        $url = "https://geokeo.com/geocode/v1/search.php?q=" . $city . "&api=11a4c13e8c4829c9fcc8d11a5a6b8e78";
        $json = file_get_contents($url);
        $json = json_decode($json);

		$latitude = $json->results[0]->geometry->location->lat;
		$longitude = $json->results[0]->geometry->location->lng;
        $cityName = $json->results[0]->address_components->name; 
        
        $apiUrl = 'https://api.openweathermap.org/data/2.5/onecall?lat=' . $latitude . '&lon=' . $longitude . '&exclude=hourly&appid=4e0012eeca831feb14b303aadbf4e714&fbclid=IwAR1hI1mO5JZgC80sdeOoWcvKYQcuRhnMpMoIjwSfYYQMC3vyN9FG4ZSHCsg';
        $data = file_get_contents($apiUrl);
        $data = json_decode($data);
 
        $getCurrentCity = $cityName;
        $getCurrentTemp = $data->current->temp;
        $getCurrentFeel = $data->current->feels_like;
        $getCurrentHumidity= $data->current->humidity;
        $getCurrentWeather = $data->current->weather[0]->main;
        $getCurrentDescription = $data->current->weather[0]->description;
        $getCurrentIcon = $data->current->weather[0]->icon;
        
        return [
            'city' => $getCurrentCity,
            'temp' => $getCurrentTemp,
            'feel' => $getCurrentFeel,
            'humidity' => $getCurrentHumidity,
            'weather' => $getCurrentWeather,
            'description' => $getCurrentDescription,
            'icon' => $getCurrentIcon,
            'data' => $data
        ];
    }
}
